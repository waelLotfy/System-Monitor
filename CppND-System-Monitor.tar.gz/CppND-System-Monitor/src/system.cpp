#include <unistd.h>
#include <cstddef>
#include <set>
#include <string>
#include <vector>
#include <algorithm>


#include "process.h"
#include "processor.h"
#include "system.h"

using std::set;
using std::size_t;
using std::string;
using std::vector;

// Return the system's CPU
Processor& System::Cpu() { return cpu_; }

// Return a container composed of the system's processes
vector<Process>& System::Processes() 
{
  processes_.clear();
  for (int pid :  System::linuxParser.Pids() )
  {
    Process process(pid);
    processes_.push_back(process);
  }
  std::sort(processes_.begin(),processes_.end());
  return processes_; 
}

// TODO: Return the system's kernel identifier (string)
std::string System::Kernel() 
{ 
    return System::linuxParser.Kernel();
}

// TODO: Return the system's memory utilization
float System::MemoryUtilization() 
{ 
    return System::linuxParser.MemoryUtilization(); 
}

// TODO: Return the operating system name
std::string System::OperatingSystem() 
{ 
    return  System::linuxParser.OperatingSystem(); 
}

// TODO: Return the number of processes actively running on the system
int System::RunningProcesses() 
{ 
    return System::linuxParser.RunningProcesses() ;
}

// TODO: Return the total number of processes on the system
int System::TotalProcesses() 
{ 
    return System::linuxParser.TotalProcesses(); 
}

// TODO: Return the number of seconds since the system started running
long int System::UpTime() 
{ 
    return System::linuxParser.UpTime();
}