#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>

#include "process.h"

using std::string;
using std::to_string;
using std::vector;

//Add Constructor
Process::Process(int id)
{
  pid     = id;
  command = linuxParser.Command(pid) ;
  user    = linuxParser.User(pid);
  uptime  = linuxParser.UpTime(pid);
  //ram     = linuxParser.Uid(id);//id; // for test only 
  ram     = linuxParser.Ram(pid);
  
  
}
// TODO: Return this process's ID
int Process::Pid() 
{ 
  return pid; 
}

// TODO: Return this process's CPU utilization
float Process::CpuUtilization() const
{ 
  vector<int> Process_Values = Process::linuxParser.ProcessUtilization(pid);
  
  unsigned long total_time = Process_Values[0] +  Process_Values[1] ; //total_time = utime + stime
  total_time = total_time +  Process_Values[2] + Process_Values[3];//total_time=total_time +cutime + cstime
  unsigned long seconds = Process::linuxParser.UpTime()- (Process_Values[4]/sysconf(_SC_CLK_TCK)) ;//seconds=uptime - (starttime / Hertz)
  
  float CPU_Percentage = (float) (  (float)( total_time / sysconf(_SC_CLK_TCK) ) / seconds) ; 

  return CPU_Percentage; 
}

// TODO: Return the command that generated this process
string Process::Command() 
{ 
  return command; 
}

// TODO: Return this process's memory utilization
string Process::Ram() 
{ 
  return ram; 
}

// TODO: Return the user (name) that generated this process
string Process::User() 
{ 
  return user; 
}

// TODO: Return the age of this process (in seconds)
long int Process::UpTime() 
{ 
  return uptime; 
}

// TODO: Overload the "less than" comparison operator for Process objects
bool Process::operator<(Process const& a) const
{ 
  return (this->CpuUtilization() < a.CpuUtilization()); 
}